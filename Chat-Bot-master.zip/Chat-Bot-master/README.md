# Chat-Bot
I made a Chat Bot using Javascript which can reply to simple basic questions.
